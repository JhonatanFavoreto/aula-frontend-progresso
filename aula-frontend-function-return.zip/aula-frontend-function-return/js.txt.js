let cor = "Azul";

function pintar() {
    let cor = "Vermelho";
    return cor;
}

cor = pintar();
console.log("Fora da função:", cor);