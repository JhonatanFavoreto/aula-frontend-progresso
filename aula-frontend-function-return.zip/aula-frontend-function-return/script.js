/*let contador = 0;

function incrementar() {
    contador += 1;
    document.getElementById("contador").textContent = contador;
}*/

let contador = 0;
let timerIniciado = false;
let tempoInicio;
let timerInterval;
let modoAtual = '100cliques';
const TEMPO_LIMITE_5S = 5000; // 5 segundos em milissegundos
const TEMPO_LIMITE_1S = 1000; // 1 segundo em milissegundos

function getTempoLimite() {
    if (modoAtual === '5segundos') return TEMPO_LIMITE_5S;
    if (modoAtual === '1segundo') return TEMPO_LIMITE_1S;
    return 0;
}

function iniciarModo(modo) {
    modoAtual = modo;
    document.getElementById("modoSelecao").style.display = "none";
    document.getElementById("jogoArea").style.display = "flex";
    
    if (modo === '100cliques') {
        document.getElementById("descricaoModo").innerText = "Chegue a 100 cliques o mais rápido possível!";
        document.getElementById("tempo").innerText = "00:00:00";
    } else if (modo === '5segundos') {
        document.getElementById("descricaoModo").innerText = "Faça o máximo de cliques em 5 segundos!";
        document.getElementById("tempo").innerText = "05:00";
    } else if (modo === '1segundo') {
        document.getElementById("descricaoModo").innerText = "Faça o máximo de cliques em 1 segundo!";
        document.getElementById("tempo").innerText = "01:00";
    }
    
    resetarJogo();
}

function incrementar() {
    // Inicia o timer no primeiro clique
    if (!timerIniciado) {
        timerIniciado = true;
        tempoInicio = Date.now();
        timerInterval = setInterval(atualizarTimer, 10);
    }
    
    // Incrementa o contador
    contador += 1;
    document.getElementById("contador").innerText = contador;
    
    // Atualiza a barra de progresso
    if (modoAtual === '100cliques') {
        const progresso = (contador / 100) * 100;
        document.getElementById("progressBar").style.width = progresso + "%";
        
        // Verifica se chegou a 100 cliques
        if (contador >= 100) {
            finalizarJogo();
        }
    }
}

function atualizarTimer() {
    const tempoDecorrido = Date.now() - tempoInicio;
    
    if (modoAtual === '100cliques') {
        const minutos = Math.floor(tempoDecorrido / 60000);
        const segundos = Math.floor((tempoDecorrido % 60000) / 1000);
        const milissegundos = Math.floor((tempoDecorrido % 1000) / 10);
        
        const tempoFormatado = 
            String(minutos).padStart(2, '0') + ':' + 
            String(segundos).padStart(2, '0') + ':' + 
            String(milissegundos).padStart(2, '0');
        
        document.getElementById("tempo").innerText = tempoFormatado;
    } else {
        // Modo 5 segundos ou 1 segundo - contagem regressiva
        const tempoLimite = getTempoLimite();
        const tempoRestante = tempoLimite - tempoDecorrido;
        
        if (tempoRestante <= 0) {
            finalizarJogo();
            return;
        }
        
        const segundos = Math.floor(tempoRestante / 1000);
        const milissegundos = Math.floor((tempoRestante % 1000) / 10);
        
        const tempoFormatado = 
            String(segundos).padStart(2, '0') + ':' + 
            String(milissegundos).padStart(2, '0');
        
        document.getElementById("tempo").innerText = tempoFormatado;
        
        // Atualiza barra de progresso baseada no tempo
        const progresso = ((tempoLimite - tempoRestante) / tempoLimite) * 100;
        document.getElementById("progressBar").style.width = progresso + "%";
    }
}

function finalizarJogo() {
    clearInterval(timerInterval);
    
    const resultado = document.getElementById("resultado");
    
    if (modoAtual === '100cliques') {
        const tempoFinal = document.getElementById("tempo").innerText;
        resultado.innerHTML = "🎉 Parabéns!<br>Você completou 100 cliques em<br><strong>" + tempoFinal + "</strong>";
    } else if (modoAtual === '5segundos') {
        document.getElementById("tempo").innerText = "00:00";
        document.getElementById("progressBar").style.width = "100%";
        resultado.innerHTML = "⚡ Tempo esgotado!<br>Você fez <strong>" + contador + " cliques</strong> em 5 segundos!";
    } else if (modoAtual === '1segundo') {
        document.getElementById("tempo").innerText = "00:00";
        document.getElementById("progressBar").style.width = "100%";
        resultado.innerHTML = "🔥 Tempo esgotado!<br>Você fez <strong>" + contador + " cliques</strong> em 1 segundo!";
    }
    
    resultado.style.display = "block";
    document.getElementById("clickBtn").disabled = true;
    document.getElementById("resetBtn").style.display = "inline-block";
    document.getElementById("voltarBtn").style.display = "inline-block";
}

function resetar() {
    resetarJogo();
}

function resetarJogo() {
    contador = 0;
    timerIniciado = false;
    clearInterval(timerInterval);
    
    document.getElementById("contador").innerText = "0";
    document.getElementById("progressBar").style.width = "0%";
    document.getElementById("resultado").style.display = "none";
    document.getElementById("clickBtn").disabled = false;
    document.getElementById("resetBtn").style.display = "none";
    document.getElementById("voltarBtn").style.display = "none";
    
    if (modoAtual === '100cliques') {
        document.getElementById("tempo").innerText = "00:00:00";
    } else if (modoAtual === '5segundos') {
        document.getElementById("tempo").innerText = "05:00";
    } else if (modoAtual === '1segundo') {
        document.getElementById("tempo").innerText = "01:00";
    }
}

function voltarMenu() {
    clearInterval(timerInterval);
    document.getElementById("jogoArea").style.display = "none";
    document.getElementById("modoSelecao").style.display = "block";
    resetarJogo();
}
